package com.qualcomm.robotcore.hardware;

/**
 * Interface to represent any hardware device that can be managed by HardwareMap.
 */
public interface HardwareDevice {
}
